﻿using System;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;

namespace plcconnect
{
    public partial class Form1 : Form
    {
        private TcpClient? client = null;
        private NetworkStream? stream = null;
        private Thread? monitorThread = null;
        private bool isMonitoring = false;

        public Form1()
        {
            InitializeComponent();
            this.FormClosing += MainForm_FormClosing;

            // Khởi động chương trình, vô hiệu hóa nút "Ngắt kết nối", "Dung theo doi"
            btnDisconnect.Enabled = false;
            btnStopMonitor.Enabled = false;
        }

        private void MainForm_FormClosing(object? sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Bạn có chắc chắn muốn thoát ứng dụng không?",
                "Xác nhận thoát",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (result == DialogResult.No)
            {
                e.Cancel = true;
            }
            else
            {
                StopMonitoring();
                Disconnect();
            }
        }

        private void btnDisconnect_Click(object sender, EventArgs e)
        {
            StopMonitoring();
            Disconnect();
            MessageBox.Show("Đã ngắt kết nối!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            string ipAddress = txtIPAddress.Text;

            // Kiểm tra điều kiện IP hợp lệ
            if (!IPAddress.TryParse(ipAddress, out _))
            {
                MessageBox.Show("Địa chỉ IP không hợp lệ.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!int.TryParse(txtPort.Text, out int port))
            {
                MessageBox.Show("Cổng phải là số nguyên hợp lệ.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                client = new TcpClient(ipAddress, port);
                stream = client.GetStream();
                MessageBox.Show("Kết nối thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Kích hoạt nút "Ngắt kết nối", vô hiệu hóa nút "Kết nối"
                btnConnect.Enabled = false;
                btnDisconnect.Enabled = true;
            }
            catch (Exception ex)
            {
                client?.Close();
                client = null;
                stream = null;
                MessageBox.Show($"Không thể kết nối: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnStartMonitor_Click(object sender, EventArgs e)
        {
            if (stream == null || client == null || !stream.CanRead)
            {
                MessageBox.Show("Chưa kết nối đến PLC.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtAddress.Text))
            {
                MessageBox.Show("Vui lòng nhập địa chỉ thanh ghi cần theo dõi.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (!isMonitoring)
            {
                isMonitoring = true;
                btnStopMonitor.Enabled = true;
                btnStartMonitor.Enabled = false;
                monitorThread = new Thread(() => MonitorRegister(txtAddress.Text));
                monitorThread.IsBackground = true;
                monitorThread.Start();
                MessageBox.Show("Đã bắt đầu theo dõi!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnStopMonitor_Click(object sender, EventArgs e)
        {
            StopMonitoring();
        }

        private void MonitorRegister(string address)
        {
            try
            {
                while (isMonitoring)
                {
                    if (stream == null || !stream.CanRead)
                    {
                        StopMonitoring();
                        return;
                    }

                    // Gửi lệnh đọc thanh ghi
                    string command = $"RD {address}\r\n";
                    byte[] commandBytes = Encoding.ASCII.GetBytes(command);
                    stream.Write(commandBytes, 0, commandBytes.Length);

                    // Đọc phản hồi từ PLC
                    byte[] buffer = new byte[1024];
                    int bytesRead = stream.Read(buffer, 0, buffer.Length);
                    string response = Encoding.ASCII.GetString(buffer, 0, bytesRead);

                    // Cập nhật giao diện trong thread-safe
                    // Duwx lieu bo nho tang len 0.1MB trong 4s
                    this.Invoke((MethodInvoker)(() =>
                    {
                        txtMonitorValue.Text = response.Trim();
                    }));

                    // Chờ một khoảng thời gian trước khi đọc lại (ví dụ: 1 giây)
                    Thread.Sleep(500);
                }
            }
            catch (Exception ex)
            {
                this.Invoke((MethodInvoker)(() =>
                {
                    MessageBox.Show($"Lỗi khi theo dõi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }));
                StopMonitoring();
            }
        }

        private void StopMonitoring()
        {
            if (isMonitoring)
            {
                isMonitoring = false;
                monitorThread?.Join(); // Đợi thread dừng lại hoàn toàn
                monitorThread = null;
                btnStartMonitor.Enabled = true;
                btnStopMonitor.Enabled = false;
                //MessageBox.Show("Đã dừng theo dõi.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void Disconnect()
        {
            StopMonitoring();
            stream?.Dispose();
            client?.Close();
            client = null;
            stream = null;

            // Reset trạng thái các nút
            btnConnect.Enabled = true;
            btnDisconnect.Enabled = false;
        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            if (stream == null || !stream.CanRead)
            {
                MessageBox.Show("Chưa kết nối đến PLC.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string address = txtAddress.Text;

            string command = $"RD {address}\r\n";
            byte[] commandBytes = Encoding.ASCII.GetBytes(command);

            try
            {
                stream.Write(commandBytes, 0, commandBytes.Length);

                byte[] buffer = new byte[1024];
                int bytesRead = stream.Read(buffer, 0, buffer.Length);
                string response = Encoding.ASCII.GetString(buffer, 0, bytesRead);

                txtResponse.Text = response;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi đọc dữ liệu: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnWrite_Click(object sender, EventArgs e)
        {
            if (stream == null || !stream.CanWrite)
            {
                MessageBox.Show("Chưa kết nối đến PLC.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string address = txtAddress.Text;
            string data = txtData.Text;

            string command = $"WR {address} {data}\r\n";
            byte[] commandBytes = Encoding.ASCII.GetBytes(command);

            try
            {
                stream.Write(commandBytes, 0, commandBytes.Length);

                byte[] buffer = new byte[1024];
                int bytesRead = stream.Read(buffer, 0, buffer.Length);
                string response = Encoding.ASCII.GetString(buffer, 0, bytesRead);

                txtResponse.Text = response;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi ghi dữ liệu: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
