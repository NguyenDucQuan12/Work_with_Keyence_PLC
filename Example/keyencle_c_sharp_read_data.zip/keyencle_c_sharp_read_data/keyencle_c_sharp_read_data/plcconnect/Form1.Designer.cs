﻿namespace plcconnect
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            btnConnect = new Button();
            txtIPAddress = new TextBox();
            label3 = new Label();
            txtPort = new TextBox();
            btnDisconnect = new Button();
            btnRead = new Button();
            btnWrite = new Button();
            label4 = new Label();
            txtAddress = new TextBox();
            label5 = new Label();
            txtResponse = new TextBox();
            label6 = new Label();
            txtData = new TextBox();
            txtMonitorValue = new TextBox();
            btnStartMonitor = new Button();
            btnStopMonitor = new Button();
            label7 = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(27, 107);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(75, 25);
            label1.TabIndex = 0;
            label1.Text = "Nhập IP";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(8, 9);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(638, 40);
            label2.TabIndex = 1;
            label2.Text = "Bật chức năng Socket trong PLC trước khi kết nối";
            // 
            // btnConnect
            // 
            btnConnect.Location = new Point(27, 663);
            btnConnect.Margin = new Padding(4, 5, 4, 5);
            btnConnect.Name = "btnConnect";
            btnConnect.Size = new Size(129, 47);
            btnConnect.TabIndex = 2;
            btnConnect.Text = "Kết nối";
            btnConnect.UseVisualStyleBackColor = true;
            btnConnect.Click += btnConnect_Click;
            // 
            // txtIPAddress
            // 
            txtIPAddress.Location = new Point(151, 102);
            txtIPAddress.Margin = new Padding(4, 5, 4, 5);
            txtIPAddress.Name = "txtIPAddress";
            txtIPAddress.Size = new Size(243, 31);
            txtIPAddress.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(27, 190);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(44, 25);
            label3.TabIndex = 4;
            label3.Text = "Port";
            // 
            // txtPort
            // 
            txtPort.Location = new Point(151, 177);
            txtPort.Margin = new Padding(4, 5, 4, 5);
            txtPort.Name = "txtPort";
            txtPort.Size = new Size(243, 31);
            txtPort.TabIndex = 5;
            txtPort.Text = "8501";
            // 
            // btnDisconnect
            // 
            btnDisconnect.Location = new Point(466, 663);
            btnDisconnect.Margin = new Padding(4, 5, 4, 5);
            btnDisconnect.Name = "btnDisconnect";
            btnDisconnect.Size = new Size(129, 47);
            btnDisconnect.TabIndex = 6;
            btnDisconnect.Text = "Ngắt kết nối";
            btnDisconnect.UseVisualStyleBackColor = true;
            btnDisconnect.Click += btnDisconnect_Click;
            // 
            // btnRead
            // 
            btnRead.Location = new Point(466, 262);
            btnRead.Margin = new Padding(4, 5, 4, 5);
            btnRead.Name = "btnRead";
            btnRead.Size = new Size(129, 47);
            btnRead.TabIndex = 7;
            btnRead.Text = "Đọc";
            btnRead.UseVisualStyleBackColor = true;
            btnRead.Click += btnRead_Click;
            // 
            // btnWrite
            // 
            btnWrite.Location = new Point(466, 352);
            btnWrite.Margin = new Padding(4, 5, 4, 5);
            btnWrite.Name = "btnWrite";
            btnWrite.Size = new Size(129, 47);
            btnWrite.TabIndex = 8;
            btnWrite.Text = "Ghi";
            btnWrite.UseVisualStyleBackColor = true;
            btnWrite.Click += btnWrite_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(27, 272);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(123, 25);
            label4.TabIndex = 9;
            label4.Text = "Vùng nhớ PLC";
            // 
            // txtAddress
            // 
            txtAddress.Location = new Point(151, 262);
            txtAddress.Margin = new Padding(4, 5, 4, 5);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(243, 31);
            txtAddress.TabIndex = 10;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(27, 438);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(89, 25);
            label5.TabIndex = 11;
            label5.Text = "Trạng thái";
            // 
            // txtResponse
            // 
            txtResponse.Location = new Point(151, 433);
            txtResponse.Margin = new Padding(4, 5, 4, 5);
            txtResponse.Name = "txtResponse";
            txtResponse.Size = new Size(243, 31);
            txtResponse.TabIndex = 12;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(27, 357);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(68, 25);
            label6.TabIndex = 13;
            label6.Text = "Dữ liệu";
            // 
            // txtData
            // 
            txtData.Location = new Point(151, 352);
            txtData.Margin = new Padding(4, 5, 4, 5);
            txtData.Name = "txtData";
            txtData.Size = new Size(243, 31);
            txtData.TabIndex = 14;
            // 
            // txtMonitorValue
            // 
            txtMonitorValue.Location = new Point(151, 515);
            txtMonitorValue.Margin = new Padding(4, 5, 4, 5);
            txtMonitorValue.Name = "txtMonitorValue";
            txtMonitorValue.Size = new Size(243, 31);
            txtMonitorValue.TabIndex = 15;
            // 
            // btnStartMonitor
            // 
            btnStartMonitor.Location = new Point(449, 507);
            btnStartMonitor.Margin = new Padding(4, 5, 4, 5);
            btnStartMonitor.Name = "btnStartMonitor";
            btnStartMonitor.Size = new Size(171, 47);
            btnStartMonitor.TabIndex = 16;
            btnStartMonitor.Text = "Bắt đầu theo dõi";
            btnStartMonitor.UseVisualStyleBackColor = true;
            btnStartMonitor.Click += btnStartMonitor_Click;
            // 
            // btnStopMonitor
            // 
            btnStopMonitor.Location = new Point(449, 582);
            btnStopMonitor.Margin = new Padding(4, 5, 4, 5);
            btnStopMonitor.Name = "btnStopMonitor";
            btnStopMonitor.Size = new Size(171, 47);
            btnStopMonitor.TabIndex = 17;
            btnStopMonitor.Text = "Dừng theo dõi";
            btnStopMonitor.UseVisualStyleBackColor = true;
            btnStopMonitor.Click += btnStopMonitor_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(13, 521);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(130, 25);
            label7.TabIndex = 18;
            label7.Text = "Giá trị theo dõi";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(659, 730);
            Controls.Add(label7);
            Controls.Add(txtMonitorValue);
            Controls.Add(btnStartMonitor);
            Controls.Add(btnStopMonitor);
            Controls.Add(txtData);
            Controls.Add(label6);
            Controls.Add(txtResponse);
            Controls.Add(label5);
            Controls.Add(txtAddress);
            Controls.Add(label4);
            Controls.Add(btnWrite);
            Controls.Add(btnRead);
            Controls.Add(btnDisconnect);
            Controls.Add(txtPort);
            Controls.Add(label3);
            Controls.Add(txtIPAddress);
            Controls.Add(btnConnect);
            Controls.Add(label2);
            Controls.Add(label1);
            Margin = new Padding(4, 5, 4, 5);
            Name = "Form1";
            Text = "Read Data From PLC";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        private Label label1;
        private Label label2;
        private Button btnConnect;
        private TextBox txtIPAddress;
        private Label label3;
        private TextBox txtPort;
        private Button btnDisconnect;
        private Button btnRead;
        private Button btnWrite;
        private Label label4;
        private TextBox txtAddress;
        private Label label5;
        private TextBox txtResponse;
        private Label label6;
        private TextBox txtData;
        private TextBox txtMonitorValue;
        private Button btnStartMonitor;
        private Button btnStopMonitor;
        private Label label7;
    }
}
