﻿namespace plcconnect
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            btnConnect = new Button();
            txtIPAddress = new TextBox();
            label3 = new Label();
            txtPort = new TextBox();
            btnDisconnect = new Button();
            btnRead = new Button();
            btnWrite = new Button();
            label4 = new Label();
            txtAddress = new TextBox();
            label5 = new Label();
            txtResponse = new TextBox();
            label6 = new Label();
            textData = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(19, 64);
            label1.Name = "label1";
            label1.Size = new Size(49, 15);
            label1.TabIndex = 0;
            label1.Text = "Nhập IP";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(87, 18);
            label2.Name = "label2";
            label2.Size = new Size(185, 25);
            label2.TabIndex = 1;
            label2.Text = "Kết nối PLC keyence ";
            // 
            // btnConnect
            // 
            btnConnect.Location = new Point(29, 289);
            btnConnect.Name = "btnConnect";
            btnConnect.Size = new Size(90, 28);
            btnConnect.TabIndex = 2;
            btnConnect.Text = "Kết nối";
            btnConnect.UseVisualStyleBackColor = true;
            btnConnect.Click += btnConnect_Click;
            // 
            // txtIPAddress
            // 
            txtIPAddress.Location = new Point(106, 61);
            txtIPAddress.Name = "txtIPAddress";
            txtIPAddress.Size = new Size(171, 23);
            txtIPAddress.TabIndex = 3;
            txtIPAddress.TextChanged += txtIPAddress_TextChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(19, 114);
            label3.Name = "label3";
            label3.Size = new Size(29, 15);
            label3.TabIndex = 4;
            label3.Text = "Port";
            // 
            // txtPort
            // 
            txtPort.Location = new Point(106, 106);
            txtPort.Name = "txtPort";
            txtPort.Size = new Size(171, 23);
            txtPort.TabIndex = 5;
            // 
            // btnDisconnect
            // 
            btnDisconnect.Location = new Point(187, 289);
            btnDisconnect.Name = "btnDisconnect";
            btnDisconnect.Size = new Size(90, 28);
            btnDisconnect.TabIndex = 6;
            btnDisconnect.Text = "Ngắt kết nối";
            btnDisconnect.UseVisualStyleBackColor = true;
            btnDisconnect.Click += btnDisconnect_Click;
            // 
            // btnRead
            // 
            btnRead.Location = new Point(326, 150);
            btnRead.Name = "btnRead";
            btnRead.Size = new Size(90, 28);
            btnRead.TabIndex = 7;
            btnRead.Text = "Đọc";
            btnRead.UseVisualStyleBackColor = true;
            btnRead.Click += btnRead_Click;
            // 
            // btnWrite
            // 
            btnWrite.Location = new Point(326, 198);
            btnWrite.Name = "btnWrite";
            btnWrite.Size = new Size(90, 28);
            btnWrite.TabIndex = 8;
            btnWrite.Text = "Ghi";
            btnWrite.UseVisualStyleBackColor = true;
            btnWrite.Click += btnWrite_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(19, 163);
            label4.Name = "label4";
            label4.Size = new Size(83, 15);
            label4.TabIndex = 9;
            label4.Text = "Vùng nhớ PLC";
            // 
            // txtAddress
            // 
            txtAddress.Location = new Point(106, 157);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(171, 23);
            txtAddress.TabIndex = 10;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(19, 263);
            label5.Name = "label5";
            label5.Size = new Size(59, 15);
            label5.TabIndex = 11;
            label5.Text = "Trạng thái";
            // 
            // txtResponse
            // 
            txtResponse.Location = new Point(106, 260);
            txtResponse.Name = "txtResponse";
            txtResponse.Size = new Size(171, 23);
            txtResponse.TabIndex = 12;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(19, 214);
            label6.Name = "label6";
            label6.Size = new Size(44, 15);
            label6.TabIndex = 13;
            label6.Text = "Dữ liệu";
            // 
            // textData
            // 
            textData.Location = new Point(106, 211);
            textData.Name = "textData";
            textData.Size = new Size(171, 23);
            textData.TabIndex = 14;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(461, 329);
            Controls.Add(textData);
            Controls.Add(label6);
            Controls.Add(txtResponse);
            Controls.Add(label5);
            Controls.Add(txtAddress);
            Controls.Add(label4);
            Controls.Add(btnWrite);
            Controls.Add(btnRead);
            Controls.Add(btnDisconnect);
            Controls.Add(txtPort);
            Controls.Add(label3);
            Controls.Add(txtIPAddress);
            Controls.Add(btnConnect);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "PLC connect -Hoàng PME";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Button btnConnect;
        private TextBox txtIPAddress;
        private Label label3;
        private TextBox txtPort;
        private Button btnDisconnect;
        private Button btnRead;
        private Button btnWrite;
        private Label label4;
        private TextBox txtAddress;
        private Label label5;
        private TextBox txtResponse;
        private Label label6;
        private TextBox textData;
    }
}
