﻿using System;
using System.Text;
using System.Windows.Forms;
using System.Net.Sockets;

namespace plcconnect
{
    public partial class Form1 : Form
    {
        private TcpClient client;
        private NetworkStream stream;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDisconnect_Click(object sender, EventArgs e)
        {

            if (stream != null) stream.Close();
            if (client != null) client.Close();
            MessageBox.Show("Đã ngắt kết nối!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            string ipAddress = txtIPAddress.Text;
            int port = int.Parse(txtPort.Text);

            try
            {
                client = new TcpClient(ipAddress, port);
                stream = client.GetStream();
                MessageBox.Show("Kết nối thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Không thể kết nối: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            if (stream == null || !stream.CanRead)
            {
                MessageBox.Show("Chưa kết nối đến PLC.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string address = txtAddress.Text;


            string command = $"RD {address}\r\n";
            byte[] commandBytes = Encoding.ASCII.GetBytes(command);
            /*nói chung tùy plc để kiểu mã hóa nào */
            try
            {
                stream.Write(commandBytes, 0, commandBytes.Length);

                byte[] buffer = new byte[1024];
                int bytesRead = stream.Read(buffer, 0, buffer.Length);
                string response = Encoding.ASCII.GetString(buffer, 0, bytesRead);

                txtResponse.Text = response;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi đọc dữ liệu: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnWrite_Click(object sender, EventArgs e)
        {
            if (stream == null || !stream.CanWrite)
            {
                MessageBox.Show("Chưa kết nối đến PLC.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string address = txtAddress.Text;
            string data = txtAddress.Text;


            string command = $"WR {address} {data}\r\n";
            byte[] commandBytes = Encoding.ASCII.GetBytes(command);

            try
            {
                stream.Write(commandBytes, 0, commandBytes.Length);

                byte[] buffer = new byte[1024];
                int bytesRead = stream.Read(buffer, 0, buffer.Length);
                string response = Encoding.ASCII.GetString(buffer, 0, bytesRead);

                txtResponse.Text = response;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi ghi dữ liệu: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void txtIPAddress_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
